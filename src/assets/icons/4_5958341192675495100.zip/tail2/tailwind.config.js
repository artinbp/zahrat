/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./*.html'],
  theme: {
    screens: {
      sm: '480px',
      md: '768px',
      lg: '976px',
      xl: '1440px'
    },
    extend: {
      colors: {
        brightRed: 'hsl(12,88%,59%)',
        redF: 'rgba(192, 35, 32, 0.3)',
        borderCCC: 'rgba(61, 61, 61, 0.5)',
        borderCC: 'rgba(61, 61, 61, 0.1)',
        borderC: 'rgba(61, 61, 61, 0.3)',
        fadeFont: 'rgba(61, 61, 61, 0.6)',
        redFont: '#C02320',
        blackFont: '#3D3D3D',
        selecC: '#EEEEEE',
        backW: "#F5F5F5",
        cardC: "#FAFAFA",
        faceC: "#337FFF",
        instaC1: "#F98B24",
        instaC2: "#DF4369",
        instaC3: "#8C3AAA",
        telegC: "#34AADF",
        whiteC: "#FFFFFF",
        linkdC: "#006699"

      },
      spacing: {
        bigRec: '1400px',
        smallRec: '1280px',
        cardRec: '375px',
        cardH: '413px',
        inmidW: '317px',
        midCW: '333px',
        selecW1: '449px',
        selecW11: '194px',
        selecW12: '255px',
        selecW2: '380px',
        selecW21: '188px',
        selecW22: '192px',
        selecW3: '260px',
        topM: '66px',
        leftM: '173px',
        arrowM: '38px',
        footH: '464px',
        pickH: '647px',
        pickW: '528px',
        picksW: '464px'
      }
    },
  },
  plugins: [],
}
